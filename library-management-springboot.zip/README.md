# 📚 Library Management System (Spring Boot + MySQL)

## Features
- Manage **Books, Students, and Issue Records**
- CRUD endpoints for `/books`, `/students`, `/issue`
- Built with **Spring Boot, MySQL, REST API**
- Tested easily with **Postman**

## Setup
1. Clone repo & open in IDE (IntelliJ/Eclipse).
2. Create MySQL DB: `library_db`.
3. Update `application.properties` with your MySQL username/password.
4. Run `LibraryManagementApplication.java`.

## Endpoints
- `GET /books`, `POST /books`, `PUT /books/{id}`, `DELETE /books/{id}`
- `GET /students`, `POST /students`, `PUT /students/{id}`, `DELETE /students/{id}`
- `GET /issue`, `POST /issue`

✅ Ready for GitHub & Resume showcase!
