package com.example.library.controller;

import com.example.library.entity.Issue;
import com.example.library.repository.IssueRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/issue")
public class IssueController {
    private final IssueRepository repository;

    public IssueController(IssueRepository repository) { this.repository = repository; }

    @GetMapping
    public List<Issue> getAll() { return repository.findAll(); }

    @PostMapping
    public Issue create(@RequestBody Issue issue) { return repository.save(issue); }
}
